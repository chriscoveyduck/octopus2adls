"""
Azure Data Lake Storage Gen2 client for writing structured data.
Provides reusable components for ADLS operations across multiple data sources.
"""