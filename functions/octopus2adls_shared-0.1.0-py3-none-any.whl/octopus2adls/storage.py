"""Re-export storage abstractions."""
from octopusclient.storage import *  # type: ignore  # noqa: F401,F403
