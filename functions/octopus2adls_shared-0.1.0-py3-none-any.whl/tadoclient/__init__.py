"""
Tado thermostat API client for temperature and heating data.
Future implementation for Tado smart thermostat integration.
"""

__all__ = ['TadoClient', 'TadoSettings']

# TODO: Implement when Tado integration is ready
# from .client import TadoClient  
# from .config import TadoSettings